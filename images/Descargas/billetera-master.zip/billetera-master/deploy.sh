#ru database migrations

php artisan migrate:fresh

# run seeds

php artisan db:seed